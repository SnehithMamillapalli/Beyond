import type { ProjectInput } from "../../shared/analysis";

export interface RepositoryRecord {
  id: string;
  name: string;
  url: string;
  description: string;
  topics: string[];
  language: string | null;
  languages: string[];
  stars: number;
  forks: number;
  license: string | null;
  updatedAt?: string;
  readme?: string;
  evidence: { label: string; url: string; excerpt: string }[];
}

export interface WebRecord {
  id: string;
  name: string;
  url: string;
  description: string;
  evidence: { label: string; url: string; excerpt: string }[];
}

const GITHUB_API = "https://api.github.com";
const MAX_README_CHARS = 12000;
const MAX_PROVIDER_BODY_BYTES = 512 * 1024;
const fetchWithTimeout = async (url: string, init: RequestInit = {}, timeoutMs = 9000) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
};

async function readJsonLimited(response: Response, maxBytes = MAX_PROVIDER_BODY_BYTES, timeoutMs = 9000): Promise<any> {
  const declaredBytes = Number(response.headers.get("content-length") || "0");
  if (declaredBytes > maxBytes) {
    if (response.body) await response.body.cancel().catch(() => {});
    throw new Error("Provider response exceeded the safe size limit.");
  }
  const reader = response.body?.getReader();
  if (!reader) throw new Error("Provider returned an empty response.");
  const read = async () => {
    const chunks: Uint8Array[] = [];
    let totalBytes = 0;
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      if (!value) continue;
      totalBytes += value.byteLength;
      if (totalBytes > maxBytes) {
        await reader.cancel().catch(() => {});
        throw new Error("Provider response exceeded the safe size limit.");
      }
      chunks.push(value);
    }
    const body = new Uint8Array(totalBytes);
    let offset = 0;
    for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.byteLength; }
    try { return JSON.parse(new TextDecoder().decode(body)); }
    catch { throw new Error("Provider returned malformed JSON."); }
  };
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([read(), new Promise<never>((_, reject) => {
      timer = setTimeout(() => { void reader.cancel().catch(() => {}); reject(new Error("Provider response timed out.")); }, timeoutMs);
    })]);
  } finally { if (timer) clearTimeout(timer); }
}

function githubHeaders() {
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "Beyond-Project-Research",
  };
  if (process.env.GITHUB_TOKEN) headers.Authorization = `Bearer ${process.env.GITHUB_TOKEN}`;
  return headers;
}

export function validateGitHubUrl(raw: string): { owner: string; repo: string; canonical: string } {
  let parsed: URL;
  try {
    parsed = new URL(raw.trim());
  } catch {
    throw new Error("Enter a valid public GitHub repository URL, such as https://github.com/owner/repo.");
  }
  if (parsed.protocol !== "https:" || parsed.hostname.toLowerCase() !== "github.com" || parsed.username || parsed.password) {
    throw new Error("Only public repositories hosted at github.com can be inspected.");
  }
  const parts = parsed.pathname.split("/").filter(Boolean);
  if (parts.length !== 2) throw new Error("Use a repository URL in the form https://github.com/owner/repo.");
  const [owner, rawRepo] = parts;
  const repo = rawRepo.replace(/\.git$/i, "");
  if (!/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$/.test(owner) || !/^[A-Za-z0-9_.-]{1,100}$/.test(repo) || repo === "." || repo === "..") {
    throw new Error("That GitHub repository path does not look valid. Check the owner and repository name.");
  }
  return { owner, repo, canonical: `https://github.com/${owner}/${repo}` };
}

function toRepository(item: any): RepositoryRecord | null {
  if (!item || typeof item.full_name !== "string" || typeof item.html_url !== "string") return null;
  return {
    id: `gh:${item.full_name.toLowerCase()}`,
    name: item.full_name,
    url: item.html_url,
    description: typeof item.description === "string" ? item.description.slice(0, 500) : "No repository description provided.",
    topics: Array.isArray(item.topics) ? item.topics.filter((value: unknown): value is string => typeof value === "string").slice(0, 15) : [],
    language: typeof item.language === "string" ? item.language : null,
    languages: typeof item.language === "string" ? [item.language] : [],
    stars: Number.isFinite(item.stargazers_count) ? item.stargazers_count : 0,
    forks: Number.isFinite(item.forks_count) ? item.forks_count : 0,
    license: item.license?.spdx_id && item.license.spdx_id !== "NOASSERTION" ? String(item.license.spdx_id) : null,
    updatedAt: typeof item.updated_at === "string" ? item.updated_at : undefined,
    evidence: [],
  };
}

const githubResponseCache = new Map<string, { expiresAt: number; data: any }>();
const GITHUB_CACHE_TTL_MS = 5 * 60 * 1000;
const MAX_GITHUB_CACHE_ITEMS = 100;
async function githubGet(path: string) {
  const cached = githubResponseCache.get(path);
  if (cached && cached.expiresAt > Date.now()) return cached.data;
  if (cached) githubResponseCache.delete(path);
  const response = await fetchWithTimeout(`${GITHUB_API}${path}`, { headers: githubHeaders() });
  if (!response.ok) {
    const error = new Error(`GitHub API returned ${response.status}.`);
    (error as Error & { status?: number }).status = response.status;
    throw error;
  }
  const data = await readJsonLimited(response);
  for (const [key, entry] of githubResponseCache) if (entry.expiresAt <= Date.now()) githubResponseCache.delete(key);
  if (githubResponseCache.size >= MAX_GITHUB_CACHE_ITEMS) {
    const oldest = githubResponseCache.keys().next().value;
    if (oldest) githubResponseCache.delete(oldest);
  }
  githubResponseCache.set(path, { expiresAt: Date.now() + GITHUB_CACHE_TTL_MS, data });
  return data;
}

export async function inspectRepository(owner: string, repo: string): Promise<RepositoryRecord> {
  const metadata = await githubGet(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`);
  const record = toRepository(metadata);
  if (!record) throw new Error("GitHub returned incomplete repository metadata.");
  record.evidence.push({ label: "Repository metadata", url: record.url, excerpt: [record.description, ...record.topics].filter(Boolean).join(" · ").slice(0, 400) });
  try {
    const readme = await githubGet(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/readme`);
    if (readme?.encoding === "base64" && typeof readme.content === "string" && typeof readme.html_url === "string") {
      const decoded = Buffer.from(readme.content, "base64").toString("utf8").slice(0, MAX_README_CHARS);
      record.readme = decoded;
      record.evidence.push({ label: "README", url: readme.html_url, excerpt: decoded.replace(/[#>*`\[\]()]/g, " ").replace(/\s+/g, " ").trim().slice(0, 1200) });
    }
  } catch {
    // README is optional; the repository metadata remains valid evidence.
  }
  return record;
}

export async function searchGitHub(queries: string[]): Promise<{ records: RepositoryRecord[]; errors: string[] }> {
  const uniqueQueries = [...new Set(queries.map(query => query.trim()).filter(Boolean))].slice(0, 3);
  const results = await Promise.allSettled(uniqueQueries.map(async query => {
    const data = await githubGet(`/search/repositories?q=${encodeURIComponent(query)}&sort=stars&order=desc&per_page=5`);
    return (Array.isArray(data?.items) ? data.items : []).map(toRepository).filter((item: RepositoryRecord | null): item is RepositoryRecord => item !== null);
  }));
  const records: RepositoryRecord[] = [];
  const errors: string[] = [];
  for (const result of results) {
    if (result.status === "fulfilled") records.push(...result.value);
    else errors.push(result.reason instanceof Error ? result.reason.message : "A GitHub search request failed.");
  }
  return { records: records.filter((record, index, all) => all.findIndex(other => other.url.toLowerCase() === record.url.toLowerCase()) === index), errors };
}

export async function searchTavily(queries: string[]): Promise<{ records: WebRecord[]; errors: string[]; available: boolean }> {
  const apiKey = process.env.TAVILY_API_KEY;
  if (!apiKey) return { records: [], errors: ["Tavily is not configured."], available: false };
  const uniqueQueries = [...new Set(queries.map(query => query.trim()).filter(Boolean))].slice(0, 2);
  const results = await Promise.allSettled(uniqueQueries.map(async query => {
    const response = await fetchWithTimeout("https://api.tavily.com/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ api_key: apiKey, query, search_depth: "basic", max_results: 5, include_answer: false, include_raw_content: false }),
    }, 11000);
    if (!response.ok) throw new Error(`Tavily search returned ${response.status}.`);
    const data = await readJsonLimited(response, MAX_PROVIDER_BODY_BYTES, 11000);
    return (Array.isArray(data?.results) ? data.results : []).flatMap((item: any): WebRecord[] => {
      if (typeof item?.url !== "string" || typeof item?.title !== "string") return [];
      let url: URL;
      try { url = new URL(item.url); } catch { return []; }
      if (url.protocol !== "https:" && url.protocol !== "http:") return [];
      const excerpt = typeof item.content === "string" ? item.content.slice(0, 900) : "";
      return [{
        id: `web:${url.hostname}${url.pathname}`.toLowerCase(),
        name: item.title.slice(0, 160),
        url: url.toString(),
        description: excerpt || "Search result returned without a descriptive excerpt.",
        evidence: [{ label: "Search result", url: url.toString(), excerpt }],
      }];
    });
  }));
  const records: WebRecord[] = [];
  const errors: string[] = [];
  for (const result of results) {
    if (result.status === "fulfilled") records.push(...result.value);
    else errors.push(result.reason instanceof Error ? result.reason.message : "A Tavily search request failed.");
  }
  const unique = records.filter((record, index, all) => all.findIndex(other => other.url === record.url) === index);
  return { records: unique, errors, available: true };
}

export function buildResearchQueries(input: ProjectInput, projectText: string, keywords: string[]) {
  const core = (input.problemStatement || input.projectDescription || projectText).replace(/\s+/g, " ").trim().slice(0, 140);
  const featurePhrase = keywords.slice(0, 5).join(" ");
  const category = input.category?.trim();
  return {
    github: [
      `${core} ${category || "software"}`.trim(),
      [featurePhrase, "open source project"].filter(Boolean).join(" "),
    ].filter(query => query.length > 2),
    web: [
      `${core} tools products alternatives`.trim(),
      [featurePhrase, "project documentation"].filter(Boolean).join(" "),
    ].filter(query => query.length > 2),
  };
}
