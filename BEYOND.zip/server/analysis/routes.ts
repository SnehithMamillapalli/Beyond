import type { Express, Request, Response } from "express";
import type { AnalysisStage, ProjectInput } from "../../shared/analysis";
import { runAnalysis, validateInput } from "./engine";

const stages: AnalysisStage[] = ["understanding", "github", "web", "comparing", "evidence", "opportunities"];
let activeAnalyses = 0;
const MAX_CONCURRENT_ANALYSES = 4;

function sendCapacityError(response: Response, stream: boolean) {
  const error = "The research desk is handling several analyses right now. Please wait a moment and retry.";
  if (stream) {
    response.status(429).set({ "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache" });
    response.write(`event: error\ndata: ${JSON.stringify({ error })}\n\n`);
    response.end();
  } else response.status(429).json({ error });
}

export function registerAnalysisRoutes(app: Express) {
  const analyze = async (request: Request, response: Response, stream: boolean) => {
    let input: ProjectInput;
    try { input = validateInput(request.body); }
    catch (error) {
      const message = error instanceof Error ? error.message : "The request could not be validated.";
      if (stream) {
        response.status(400).set("Content-Type", "text/event-stream").set("Cache-Control", "no-cache");
        response.write(`event: error\ndata: ${JSON.stringify({ error: message })}\n\n`);
        response.end();
      } else response.status(400).json({ error: message });
      return;
    }
    if (stream) {
      response.status(200);
      response.set({ "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive", "X-Accel-Buffering": "no" });
      response.flushHeaders?.();
      const send = (event: string, data: unknown) => response.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
      try {
        const report = await runAnalysis(input, stage => send("stage", { stage }), profile => send("profile", { profile }));
        send("result", report);
      } catch (error) {
        send("error", { error: error instanceof Error ? error.message : "Analysis could not be completed." });
      }
      response.end();
      return;
    }
    try {
      const report = await runAnalysis(input);
      response.json(report);
    } catch (error) {
      response.status(400).json({ error: error instanceof Error ? error.message : "Analysis could not be completed." });
    }
  };

  const dispatch = (request: Request, response: Response, stream: boolean) => {
    if (activeAnalyses >= MAX_CONCURRENT_ANALYSES) { sendCapacityError(response, stream); return; }
    activeAnalyses += 1;
    void analyze(request, response, stream).then(
      () => { activeAnalyses = Math.max(0, activeAnalyses - 1); },
      () => { activeAnalyses = Math.max(0, activeAnalyses - 1); },
    );
  };

  app.post("/api/analyze", (request, response) => dispatch(request, response, false));
  app.post("/api/analyze/stream", (request, response) => dispatch(request, response, true));
  app.get("/api/health", (_request, response) => response.json({ status: "ok", providers: {
    github: true,
    tavily: Boolean(process.env.TAVILY_API_KEY),
    ai: Boolean(process.env.MANUS_API_URL && process.env.MANUS_API_KEY),
  } }));
}
