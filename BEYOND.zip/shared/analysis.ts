export type SourceKind = "USER-PROVIDED" | "REPOSITORY-OBSERVED" | "AI-INFERRED";

export interface Sourced<T> {
  value: T | null;
  source: SourceKind;
}

export interface ProjectInput {
  problemStatement?: string;
  projectDescription?: string;
  githubUrl?: string;
  projectName?: string;
  category?: string;
  targetUsers?: string;
  existingFeatures?: string;
  plannedFeatures?: string;
  languages?: string;
  technologies?: string;
  database?: string;
  aiStack?: string;
  architecture?: string;
  constraints?: string;
  desiredImprovements?: string;
}

export interface ProjectProfile {
  name: Sourced<string>;
  problem: Sourced<string>;
  solution: Sourced<string>;
  targetUsers: Sourced<string>;
  coreFeatures: Sourced<string[]>;
  plannedFeatures: Sourced<string[]>;
  technologies: Sourced<string[]>;
  architecture: Sourced<string>;
  differentiators: Sourced<string[]>;
  constraints: Sourced<string[]>;
  unknowns: string[];
}

export type EvidenceStatus = "Verified" | "Inferred" | "Unknown" | "Proposed by user";

export interface EvidenceItem {
  label: string;
  url: string;
  excerpt: string;
  status: EvidenceStatus;
}

export interface SimilarityDimensions {
  problem?: number;
  features?: number;
  audience?: number;
  technical?: number;
}

export interface ComparableProject {
  id: string;
  name: string;
  url: string;
  source: "GitHub" | "Web";
  description: string;
  whyRelevant: string;
  sharedFeatures: string[];
  distinctiveFeatures: string[];
  technologies: string[];
  dimensions: SimilarityDimensions;
  similarity: number | null;
  evidence: EvidenceItem[];
  limitations: string[];
  stars?: number;
  forks?: number;
  language?: string | null;
  license?: string | null;
  updatedAt?: string;
}

export interface InnovationOpportunity {
  id: string;
  kind: "Feature" | "Technical" | "Experience" | "Problem space";
  title: string;
  proposal: string;
  problem: string;
  whyDifferent: string;
  evidence: { projectName: string; note: string; url?: string }[];
  benefit: string;
  effort: "Low" | "Medium" | "High";
  validation: string;
  uncertainties: string[];
}

export interface ResearchReport {
  profile: ProjectProfile;
  candidates: ComparableProject[];
  submittedRepository?: { name: string; url: string; description: string; features: string[]; evidenceCount: number };
  opportunities: InnovationOpportunity[];
  discoveredCount: number;
  inspectedCount: number;
  sources: { github: boolean; tavily: boolean; ai: boolean };
  timestamp: string;
  limitations: string[];
  rankingNote: string;
}

export type AnalysisStage =
  | "understanding"
  | "github"
  | "web"
  | "comparing"
  | "evidence"
  | "opportunities";
