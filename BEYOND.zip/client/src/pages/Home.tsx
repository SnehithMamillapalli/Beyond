import { useMemo, useState } from "react";
import { ArrowDown, ArrowRight, ArrowUpRight, BookOpen, Check, ChevronDown, CircleHelp, Compass, ExternalLink, FileSearch, Github, Lightbulb, LoaderCircle, Menu, Pause, Play, Plus, Radar, RotateCcw, Search, Sparkles, X } from "lucide-react";
import type { AnalysisStage, ComparableProject, InnovationOpportunity, ProjectInput, ProjectProfile, ResearchReport, Sourced } from "../../../shared/analysis";
import AeroShards from "../components/AeroShards";

type View = "new" | "results";
const STAGES: { id: AnalysisStage; label: string; note: string }[] = [
  { id: "understanding", label: "Understanding your project", note: "Building a source-aware project profile" },
  { id: "github", label: "Searching GitHub", note: "Looking for real public repositories" },
  { id: "web", label: "Exploring the wider web", note: "Checking products and documentation" },
  { id: "comparing", label: "Comparing relevant projects", note: "Ranking the available evidence" },
  { id: "evidence", label: "Extracting evidence", note: "Separating findings from inference" },
  { id: "opportunities", label: "Finding innovation paths", note: "Turning comparison into next steps" },
];
const EXAMPLES = [
  { title: "Study smarter", text: "Build an AI tool that helps students remember what they learn and plan effective revision schedules." },
  { title: "Accessible local transit", text: "A community-powered app that helps wheelchair users find step-free routes and report broken lifts." },
  { title: "Small-team research", text: "A lightweight research library that helps small teams capture sources, connect findings, and turn them into product decisions." },
];
const JOURNEY_STEPS = [
  { id: "discover", short: "DISCOVER", label: "Find similar projects", title: "Look beyond the obvious match.", note: "Find real products and repositories solving nearby problems." },
  { id: "compare", short: "COMPARE", label: "Compare useful features", title: "Separate overlap from guesswork.", note: "See where features line up—and where the evidence is still missing." },
  { id: "next", short: "TRY NEXT", label: "Choose your next step", title: "Turn a useful gap into a test.", note: "Choose a small experiment that helps your idea stand apart." },
] as const;
const sourceLabels: Record<string, string> = { "USER-PROVIDED": "You provided", "REPOSITORY-OBSERVED": "Observed in repo", "AI-INFERRED": "AI inference" };
const RADAR_AXES = [
  { key: "problem", label: "Problem" },
  { key: "features", label: "Features" },
  { key: "audience", label: "Audience" },
  { key: "technical", label: "Technical" },
] as const;

function fieldValue<T>(field?: Sourced<T> | null): T | null { return field?.value ?? null; }
function SourcePill({ source }: { source?: string }) {
  if (!source) return null;
  return <span className={`source-pill source-${source.toLowerCase().replace(/[^a-z]+/g, "-")}`}><i />{sourceLabels[source] || source}</span>;
}
function TagList({ items, muted = false }: { items: string[]; muted?: boolean }) {
  if (!items.length) return <span className="unknown-inline">Not established yet</span>;
  return <div className={`tag-list ${muted ? "tag-muted" : ""}`}>{items.map((item, index) => <span className="tag" key={`${item}-${index}`}>{item}</span>)}</div>;
}
function countLabel(count: number, singular: string, plural = `${singular}s`) { return `${count} ${count === 1 ? singular : plural}`; }

export default function Home() {
  const [view, setView] = useState<View>("new");
  const [expanded, setExpanded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [stage, setStage] = useState<AnalysisStage>("understanding");
  const [profilePreview, setProfilePreview] = useState<ProjectProfile | null>(null);
  const [report, setReport] = useState<ResearchReport | null>(null);
  const [selectedPath, setSelectedPath] = useState<string | null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [brandLogoFailed, setBrandLogoFailed] = useState(false);
  const [form, setForm] = useState<ProjectInput>({ problemStatement: "" });
  const [activeJourney, setActiveJourney] = useState(0);
  const [motionPaused, setMotionPaused] = useState(() => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

  const activeJourneyStep = JOURNEY_STEPS[activeJourney];
  const currentStageIndex = STAGES.findIndex(item => item.id === stage);
  const selectedOpportunity = report?.opportunities.find(item => item.id === selectedPath) || null;

  const update = (key: keyof ProjectInput, value: string) => setForm(current => ({ ...current, [key]: value }));
  const showResults = () => { setView("results"); setMobileMenu(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const beginNew = () => { setView("new"); setReport(null); setProfilePreview(null); setSelectedPath(null); setError(""); setBusy(false); setMobileMenu(false); window.scrollTo({ top: 0, behavior: "smooth" }); };

  async function analyze(mode: "idea" | "repo", analysisInput: ProjectInput = form) {
    setError("");
    setProfilePreview(null);
    if (mode === "repo" && !analysisInput.githubUrl?.trim()) {
      setExpanded(true);
      setError("Add a public GitHub repository URL below, or start with your idea instead.");
      document.getElementById("repo-url")?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    const hasInput = Object.values(analysisInput).some(value => typeof value === "string" && value.trim());
    if (!hasInput) { setError("Start with a problem statement, project description, or public GitHub repository."); return; }
    setBusy(true);
    setStage("understanding");
    setView("new");
    try {
      const response = await fetch("/api/analyze/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(analysisInput),
      });
      if (!response.ok && !response.headers.get("content-type")?.includes("text/event-stream")) {
        const body = await response.json().catch(() => ({}));
        throw new Error(body.error || "Analysis request failed. Check your inputs and try again.");
      }
      if (!response.body) throw new Error("The analysis stream could not be opened. Please retry.");
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let received: ResearchReport | null = null;
      while (true) {
        const { value, done } = await reader.read();
        buffer += decoder.decode(value || new Uint8Array(), { stream: !done });
        const blocks = buffer.split("\n\n");
        buffer = blocks.pop() || "";
        for (const block of blocks) {
          const event = block.match(/^event: (.+)$/m)?.[1];
          const data = block.match(/^data: (.+)$/m)?.[1];
          if (!event || !data) continue;
          const parsed = JSON.parse(data);
          if (event === "stage" && STAGES.some(item => item.id === parsed.stage)) setStage(parsed.stage);
          if (event === "profile" && parsed.profile && typeof parsed.profile === "object") setProfilePreview(parsed.profile as ProjectProfile);
          if (event === "result") { received = parsed as ResearchReport; setProfilePreview(null); }
          if (event === "error") {
            const canContinueWithoutRepo = Boolean((analysisInput.problemStatement?.trim() || analysisInput.projectDescription?.trim()) && analysisInput.githubUrl?.trim());
            const message = parsed.error || "The analysis could not be completed.";
            throw new Error(canContinueWithoutRepo ? `${message} Clear the repository URL to continue with the idea only.` : message);
          }
        }
        if (done) break;
      }
      if (!received) throw new Error("The analysis ended without a report. Please retry.");
      setReport(received);
      setView("results");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Something interrupted the analysis. Please try again.");
    } finally { setBusy(false); }
  }

  const featureRows = useMemo(() => {
    if (!report) return [];
    const features = new Map<string, string>();
    const add = (items: string[] | null, source: string) => {
      for (const feature of items || []) {
        const prior = features.get(feature);
        const priority = (value: string) => value === "USER-PROVIDED" ? 3 : value === "REPOSITORY-OBSERVED" ? 2 : 1;
        if (!prior || priority(source) > priority(prior)) features.set(feature, source);
      }
    };
    add(report.profile.plannedFeatures.value, report.profile.plannedFeatures.source);
    add(report.profile.coreFeatures.value, report.profile.coreFeatures.source);
    add(report.submittedRepository?.features || [], "REPOSITORY-OBSERVED");
    if (!features.size) {
      const fallbackSource = report.candidates.some(candidate => candidate.source === "GitHub") ? "REPOSITORY-OBSERVED" : "AI-INFERRED";
      add([...new Set(report.candidates.flatMap(candidate => candidate.sharedFeatures))], fallbackSource);
    }
    return [...features].slice(0, 8).map(([feature, source]) => ({ feature, source }));
  }, [report]);

  const selectedProposal = selectedOpportunity && report ? {
    concept: `${fieldValue(report.profile.name) || "Your project"} — ${selectedOpportunity.title}`,
    problem: fieldValue(report.profile.problem) || selectedOpportunity.problem,
    users: fieldValue(report.profile.targetUsers) || "Confirm the first target user group during validation.",
    features: (fieldValue(report.profile.coreFeatures) || []).slice(0, 5),
    differentiator: selectedOpportunity.proposal,
    approach: `${fieldValue(report.profile.architecture) ? `Extend the existing ${fieldValue(report.profile.architecture)} architecture` : "Keep this as a small, separable module; architecture is not established yet"} using ${(fieldValue(report.profile.technologies) || []).join(", ") || "the smallest stack that meets the project's constraints"}. ${selectedOpportunity.proposal} Preserve known constraints and verify external or repository claims against linked evidence.`,
    complexity: selectedOpportunity.effort,
    validation: selectedOpportunity.validation,
  } : null;

  return <div className="beyond-shell">
    <AeroShards shardColor="#4f895f" accentColor="#a9cf58" placement="full" material="glass" markers="plus" count={700} depthOfField={0.2} vignette={0.12} mouseInteraction pulseOnClick holdToGather />
    <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
      <div className="brand-identity">
        <div className="brand-lockup">
          <img src={brandLogoFailed ? "/beyond-logo.jpeg" : "/manus-storage/beyond-logo_ef2d429d.jpeg"} onError={() => setBrandLogoFailed(true)} alt="Beyond" className="brand-logo-image" />
          <span className="brand-trails" aria-hidden="true">
            <span className="brand-trail brand-trail-one" />
            <span className="brand-trail brand-trail-two" />
            <span className="brand-trail brand-trail-three" />
          </span>
        </div>
        <span className="brand-tagline">PROJECT INTELLIGENCE</span>
      </div>
      <div className="rail-label">Workspace</div>
      <button className={`rail-link ${view === "new" ? "rail-active" : ""}`} onClick={beginNew}><Plus size={17} strokeWidth={1.8} /><span>New Analysis</span></button>
      {report && <button className={`rail-link ${view === "results" ? "rail-active" : ""}`} onClick={showResults}><FileSearch size={17} strokeWidth={1.8} /><span>Analysis Results</span><span className="rail-count">01</span></button>}
      <div className="rail-divider" />
      <section className="sidebar-feature-section" aria-label="Beyond capabilities">
        <div className="sidebar-feature-heading"><span>Inside Beyond</span><span>3 CAPABILITIES</span></div>
        <div className="sidebar-feature-list">
          <details className="sidebar-feature-card" open>
            <summary><span className="sidebar-feature-icon"><Search size={14} /></span><span className="sidebar-feature-title"><strong>Tavily research bot</strong><small>WIDER-WEB SEARCH</small></span><ChevronDown size={13} className="sidebar-feature-chevron" /></summary>
            <p>Finds products, docs, and adjacent approaches—and keeps source links close.</p>
          </details>
          <details className="sidebar-feature-card" open>
            <summary><span className="sidebar-feature-icon"><Github size={14} /></span><span className="sidebar-feature-title"><strong>GitHub research engine</strong><small>PUBLIC REPO EVIDENCE</small></span><ChevronDown size={13} className="sidebar-feature-chevron" /></summary>
            <p>Checks public repo details and README evidence—never runs submitted code.</p>
          </details>
          <details className="sidebar-feature-card" open>
            <summary><span className="sidebar-feature-icon"><Lightbulb size={14} /></span><span className="sidebar-feature-title"><strong>Innovation paths</strong><small>EVIDENCE → NEXT STEPS</small></span><ChevronDown size={13} className="sidebar-feature-chevron" /></summary>
            <p>Turns overlaps and open questions into three practical directions to test.</p>
          </details>
        </div>
      </section>
      <div className="sidebar-bottom">
        <span className="live-indicator" />
        <span>Ideas, made clearer</span>
        <span className="sidebar-bottom-num">BY / 01</span>
      </div>
    </aside>

    <div className="workspace">
      <header className="topbar">
        <button className="mobile-menu-button" aria-label="Open navigation" onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu ? <X size={19} /> : <Menu size={19} />}</button>
        <div className="breadcrumb"><span>BEYOND</span><span className="breadcrumb-slash">/</span><span>{view === "results" ? "PROJECT ANALYSIS" : "NEW ANALYSIS"}</span></div>
        <div className="topbar-right"><span className="topbar-status"><span className="status-dot" />Ready when you are</span><span className="topbar-divider" /><span className="date-stamp">{new Date().toLocaleDateString("en", { day: "2-digit", month: "short", year: "2-digit" }).toUpperCase()}</span></div>
      </header>

      <main className="page-content">
        {busy ? <section className="progress-view">
          <div className="eyebrow"><span className="eyebrow-mark">01</span> ANALYSIS IN PROGRESS</div>
          <h1 className="progress-title">We’re reviewing<br />your project<span className="period">.</span></h1>
          <p className="progress-copy">We’re checking real projects and looking for useful next steps.</p>
          <div className="progress-board">
            {STAGES.map((item, index) => {
              const complete = index < currentStageIndex;
              const active = index === currentStageIndex;
              return <div className={`progress-row ${complete ? "progress-complete" : ""} ${active ? "progress-active" : ""}`} key={item.id}>
                <div className="progress-marker">{complete ? <Check size={14} /> : active ? <LoaderCircle size={15} className="spin" /> : <span>{String(index + 1).padStart(2, "0")}</span>}</div>
                <div className="progress-copy-block"><strong>{item.label}</strong><span>{item.note}</span></div>
                {complete && <span className="progress-done-label">DONE</span>}
                {active && <span className="progress-live-label">IN PROGRESS</span>}
              </div>;
            })}
          </div>
          {profilePreview && <ProfilePreviewCard profile={profilePreview} />}
          <p className="progress-footnote"><CircleHelp size={14} /> We only show findings supported by the sources we checked.</p>
        </section> : view === "results" && report ? <ResultsView report={report} featureRows={featureRows} selectedPath={selectedPath} onSelectPath={setSelectedPath} selectedProposal={selectedProposal} onNew={beginNew} onRetry={() => void analyze(form.githubUrl?.trim() ? "repo" : "idea")} onReanalyze={edits => { const nextForm = { ...form, ...edits }; setForm(nextForm); setExpanded(true); void analyze(nextForm.githubUrl?.trim() ? "repo" : "idea", nextForm); }} /> : <section className="intake-view">
          <div className="eyebrow"><span className="eyebrow-mark">01</span> YOUR NEXT IDEA</div>
          <div className="intake-layout">
            <div className="intake-main">
              <h1 className="hero-title">Have an idea?<br /><em>Let's make it better.</em></h1>
              <p className="hero-subtitle">Describe your project, paste a GitHub link, or share a problem you want to solve. We’ll find similar projects and suggest ways to make yours stand out.</p>
              <div className="input-card">
                <label className="field-label" htmlFor="problem">YOUR PROJECT OR THE PROBLEM TO SOLVE <span className="optional-tag">START HERE</span></label>
                <textarea id="problem" className="problem-textarea" rows={4} maxLength={5000} placeholder="Describe your project, or start with the problem you want to solve." value={form.problemStatement || ""} onChange={event => update("problemStatement", event.target.value)} disabled={busy} />
                <div className="textarea-footer"><span>A problem statement is enough to begin.</span><span>{(form.problemStatement || "").length.toLocaleString()} / 5,000</span></div>
                <div className="form-divider" />
                <div className="repo-row">
                  <div className="repo-label"><Github size={17} /><div><strong>Add a GitHub link</strong><span>Optional · public repository</span></div></div>
                  <input id="repo-url" className="repo-input" placeholder="github.com/you/project" value={form.githubUrl || ""} onChange={event => update("githubUrl", event.target.value)} disabled={busy} aria-label="Public GitHub repository URL" />
                </div>
                <button className="details-toggle" type="button" onClick={() => setExpanded(!expanded)} aria-expanded={expanded}><span className="details-toggle-left"><span className={`toggle-plus ${expanded ? "toggle-minus" : ""}`}>{expanded ? "−" : "+"}</span>Add more details <span className="details-optional">(optional)</span></span><ChevronDown size={16} className={expanded ? "chevron-up" : ""} /></button>
                {expanded && <div className="details-fields">
                  <label className="field-label" htmlFor="project-description">YOUR PROJECT DESCRIPTION <span className="optional-tag">OPTIONAL</span></label>
                  <textarea id="project-description" className="detail-textarea" rows={3} maxLength={5000} placeholder="What are you thinking of building?" value={form.projectDescription || ""} onChange={event => update("projectDescription", event.target.value)} />
                  <div className="detail-grid">
                    <DetailField id="project-name" label="PROJECT NAME" value={form.projectName} placeholder="Working title" onChange={value => update("projectName", value)} />
                    <DetailField id="category" label="CATEGORY" value={form.category} placeholder="e.g. Education" onChange={value => update("category", value)} />
                    <DetailField id="target-users" label="TARGET USERS" value={form.targetUsers} placeholder="Who is this for?" onChange={value => update("targetUsers", value)} />
                    <DetailField id="languages" label="LANGUAGES / STACK" value={form.languages} placeholder="e.g. TypeScript, Python" onChange={value => update("languages", value)} />
                  </div>
                  <label className="field-label detail-label" htmlFor="existing-features">EXISTING FEATURES <span className="optional-tag">OPTIONAL</span></label>
                  <textarea id="existing-features" className="detail-textarea detail-short" rows={2} placeholder="Separate features with commas" value={form.existingFeatures || ""} onChange={event => update("existingFeatures", event.target.value)} />
                  <label className="field-label detail-label" htmlFor="planned-features">PLANNED FEATURES <span className="optional-tag">OPTIONAL</span></label>
                  <textarea id="planned-features" className="detail-textarea detail-short" rows={2} placeholder="What’s on the roadmap?" value={form.plannedFeatures || ""} onChange={event => update("plannedFeatures", event.target.value)} />
                  <div className="detail-grid detail-grid-last">
                    <DetailField id="technologies" label="FRONTEND / BACKEND" value={form.technologies} placeholder="Frameworks, services" onChange={value => update("technologies", value)} />
                    <DetailField id="database" label="DATABASE" value={form.database} placeholder="If known" onChange={value => update("database", value)} />
                    <DetailField id="ai-stack" label="AI / MACHINE LEARNING" value={form.aiStack} placeholder="If relevant" onChange={value => update("aiStack", value)} />
                    <DetailField id="architecture" label="ARCHITECTURE / CONSTRAINTS" value={form.architecture} placeholder="Describe briefly" onChange={value => update("architecture", value)} />
                  </div>
                  <label className="field-label detail-label" htmlFor="constraints">CONSTRAINTS / DESIRED IMPROVEMENTS <span className="optional-tag">OPTIONAL</span></label>
                  <textarea id="constraints" className="detail-textarea detail-short" rows={2} placeholder="What should the analysis keep in mind?" value={form.constraints || ""} onChange={event => update("constraints", event.target.value)} />
                  <DetailField id="improvements" label="AREAS YOU WANT TO IMPROVE" value={form.desiredImprovements} placeholder="Optional" onChange={value => update("desiredImprovements", value)} />
                </div>}
                {error && <div className="inline-error" role="alert"><CircleHelp size={16} />{error}</div>}
                {!busy && error && profilePreview && <ProfilePreviewCard profile={profilePreview} />}
                <div className="action-row">
                  <button className="primary-action" type="button" onClick={() => void analyze("idea")} disabled={busy}><span>Analyze My Project</span><ArrowRight size={17} /></button>
                  <button className="secondary-action" type="button" onClick={() => void analyze("repo")} disabled={busy}><Github size={16} /><span>Analyze GitHub Repository</span></button>
                </div>
                <div className="privacy-line"><span className="privacy-asterisk">✳</span> No account required <span>·</span> Only public repositories are inspected <span>·</span> Repository code is never executed</div>
              </div>
              <div className="examples-row"><span className="examples-label">TRY AN EXAMPLE</span><div className="example-chips">{EXAMPLES.map(example => <button key={example.title} className="example-chip" onClick={() => update("problemStatement", example.text)}>{example.title}<ArrowUpRight size={12} /></button>)}</div></div>
            </div>
            <aside className={`field-aside journey-card ${motionPaused ? "journey-paused" : "journey-motion-enabled"}`}>
              <div className="journey-header"><div><span>BEYOND / RESEARCH FLOW</span><small>IDEA → EVIDENCE → NEXT STEP</small></div><button type="button" className="journey-motion-toggle" onClick={() => setMotionPaused(paused => !paused)} aria-label={motionPaused ? "Play map animation" : "Pause map animation"} aria-pressed={!motionPaused} title={motionPaused ? "Play animation" : "Pause animation"}>{motionPaused ? <Play size={13} /> : <Pause size={13} />}</button></div>
              <div className={`journey-visual journey-stage-${activeJourney}`} role="group" aria-label="Interactive project research map">
                <svg className="journey-svg" viewBox="0 0 220 210" aria-hidden="true" focusable="false"><circle className="journey-ring journey-ring-outer" cx="110" cy="105" r="85" /><circle className="journey-ring journey-ring-middle" cx="110" cy="105" r="63" /><circle className="journey-ring journey-ring-inner" cx="110" cy="105" r="39" /><path className="journey-route" d="M150 64 C193 76 192 127 176 146 C144 178 83 171 43 145 C20 112 54 70 86 61" /><circle className="journey-map-dot journey-map-dot-discover" cx="150" cy="64" r="5" /><circle className="journey-map-dot journey-map-dot-compare" cx="43" cy="145" r="5" /><circle className="journey-map-dot journey-map-dot-next" cx="176" cy="146" r="5" /></svg>
                <span className="journey-orbiting-signal" aria-hidden="true"><i /></span>
                <div className="journey-core"><Sparkles size={15} /><span>YOUR<br />IDEA</span></div>
                {JOURNEY_STEPS.map((step, index) => <button type="button" key={step.id} className={`journey-node journey-node-${step.id} ${activeJourney === index ? "is-active" : ""}`} onClick={() => setActiveJourney(index)} aria-label={`Show ${step.label}`} aria-pressed={activeJourney === index}>{step.short}</button>)}
              </div>
              <div className="journey-story" key={activeJourneyStep.id}><span className="journey-story-index">0{activeJourney + 1} / RESEARCH PATH</span><strong>{activeJourneyStep.title}</strong><p>{activeJourneyStep.note}</p></div>
              <div className="journey-step-list" role="group" aria-label="Choose a research stage">{JOURNEY_STEPS.map((step, index) => <button type="button" key={step.id} className={`journey-step ${activeJourney === index ? "is-active" : ""}`} onClick={() => setActiveJourney(index)} aria-pressed={activeJourney === index}><span className="journey-step-count">0{index + 1}</span><span>{step.label}</span><ArrowRight size={14} /></button>)}</div>
              <div className="aside-foot">Clearer ideas start here.</div>
            </aside>
          </div>
        </section>}
      </main>
    </div>
  </div>;
}

function DetailField({ id, label, value, placeholder, onChange }: { id: string; label: string; value?: string; placeholder: string; onChange: (value: string) => void }) {
  return <label className="detail-field" htmlFor={id}><span className="field-label">{label}</span><input id={id} className="detail-input" value={value || ""} placeholder={placeholder} onChange={event => onChange(event.target.value)} /></label>;
}

function ResultsView({ report, featureRows, selectedPath, onSelectPath, selectedProposal, onNew, onRetry, onReanalyze }: { report: ResearchReport; featureRows: { feature: string; source: string }[]; selectedPath: string | null; onSelectPath: (id: string) => void; selectedProposal: any; onNew: () => void; onRetry: () => void; onReanalyze: (updates: Partial<ProjectInput>) => void }) {
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileDraft, setProfileDraft] = useState<Partial<ProjectInput>>({});
  const [profileBaseline, setProfileBaseline] = useState<Partial<ProjectInput>>({});
  const profile = report.profile;
  const candidateColumns = report.candidates.slice(0, 3);
  const overlap = report.candidates.slice(0, 5).map(candidate => ({ name: candidate.name.split("/").pop() || candidate.name, score: candidate.similarity, features: candidate.sharedFeatures.length }));
  const radarMetrics = RADAR_AXES.map(axis => {
    const scores = candidateColumns.map(candidate => candidate.dimensions[axis.key]).filter((value): value is number => typeof value === "number");
    return { ...axis, value: scores.length ? Math.round(scores.reduce((sum, value) => sum + value, 0) / scores.length) : null };
  });
  const sourceCount = [report.sources.github, report.sources.tavily, report.sources.ai].filter(Boolean).length;
  const sourceNames = [report.sources.github ? "GitHub" : null, report.sources.tavily ? "Web" : null, report.sources.ai ? "AI" : null].filter((name): name is string => name !== null).join(" · ");
  const providerIssue = report.limitations.some(note => /(not configured|unavailable|could not be reached|request failed|rate limit reached|inspection failed)/i.test(note));
  const researchStatus = sourceCount < 3 || providerIssue ? "Limited" : "Ready";
  const citations = report.candidates.flatMap(candidate => candidate.evidence);
  const openProfileEditor = () => {
    const draft: Partial<ProjectInput> = { projectName: fieldValue(profile.name) || "", problemStatement: fieldValue(profile.problem) || "", projectDescription: fieldValue(profile.solution) || "", targetUsers: fieldValue(profile.targetUsers) || "", existingFeatures: (fieldValue(profile.coreFeatures) || []).join(", "), plannedFeatures: (fieldValue(profile.plannedFeatures) || []).join(", "), technologies: (fieldValue(profile.technologies) || []).join(", "), architecture: fieldValue(profile.architecture) || "", desiredImprovements: (fieldValue(profile.differentiators) || []).join(", "), constraints: (fieldValue(profile.constraints) || []).join(", ") };
    setProfileDraft(draft);
    setProfileBaseline(draft);
    setEditingProfile(true);
  };
  const focusProfileField = (fieldId: string) => {
    openProfileEditor();
    window.setTimeout(() => {
      document.getElementById("profile-editor")?.scrollIntoView({ behavior: "smooth", block: "center" });
      window.setTimeout(() => document.getElementById(fieldId)?.focus({ preventScroll: true }), 220);
    }, 0);
  };
  const updateProfileDraft = (key: keyof ProjectInput, value: string) => setProfileDraft(current => ({ ...current, [key]: value }));
  const changedProfile = (): Partial<ProjectInput> => {
    const changed: Partial<ProjectInput> = {};
    for (const key of Object.keys(profileDraft) as (keyof ProjectInput)[]) {
      const value = profileDraft[key] || "";
      const baseline = profileBaseline[key] || "";
      if (value.trim() !== baseline.trim()) Object.assign(changed, { [key]: value });
    }
    return changed;
  };
  return <section className="results-view">
    <div className="results-heading-row"><div><div className="eyebrow"><span className="eyebrow-mark">02</span> PROJECT ANALYSIS / {new Date(report.timestamp).toLocaleDateString("en", { day: "2-digit", month: "short", year: "numeric" }).toUpperCase()}</div><h1 className="results-title">Your Project Analysis<span className="period">.</span></h1><p className="results-subtitle">See similar projects, compare features, and discover ways to improve your idea.</p></div><button className="start-over-button" onClick={onNew}><RotateCcw size={14} />New analysis</button></div>
    <div className="research-stats">
      <div className="summary-stat"><div className="summary-stat-top"><span>Projects Found</span><span className="summary-stat-icon"><Search size={18} /></span></div><strong>{report.discoveredCount.toLocaleString()}</strong><span className="stat-note">Results returned by live sources</span></div>
      <div className="summary-stat"><div className="summary-stat-top"><span>Projects Reviewed</span><span className="summary-stat-icon"><FileSearch size={18} /></span></div><strong>{report.inspectedCount.toLocaleString()}</strong><span className="stat-note">GitHub repositories and README files</span></div>
      <div className="summary-stat"><div className="summary-stat-top"><span>Sources Used</span><span className="summary-stat-icon"><Radar size={18} /></span></div><strong>{sourceCount}</strong><span className="stat-note">{sourceNames || "No sources responded"}</span></div>
      <div className={`summary-stat summary-stat-status ${researchStatus === "Ready" ? "status-ready" : "status-limited"}`}><div className="summary-stat-top"><span>Research Status</span><span className="summary-stat-icon">{researchStatus === "Ready" ? <Check size={18} /> : <CircleHelp size={18} />}</span></div><strong className="stat-status">{researchStatus}</strong><span className="stat-note">{researchStatus === "Ready" ? "Available sources responded" : "Open Research Notes"}</span><span className="stat-timestamp">Updated {new Date(report.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span></div>
    </div>

    {report.limitations.length > 0 && <details className="research-notes"><summary><span className="research-notes-heading"><CircleHelp size={18} /><span><strong>Research Notes</strong><small>{report.limitations.length} note{report.limitations.length === 1 ? "" : "s"} about search coverage</small></span></span><ChevronDown size={18} className="research-notes-chevron" /></summary><div className="research-notes-content"><ul>{report.limitations.map((item, index) => <li key={index}>{item}</li>)}</ul><button className="coverage-retry" onClick={onRetry}><RotateCcw size={15} />Try Again</button></div></details>}

    <section className="dossier-section profile-section" id="project-profile"><div className="section-kicker"><span>01</span> YOUR PROJECT OVERVIEW</div><div className="profile-panel"><div className="profile-main"><div className="profile-head"><div><span className="profile-overline">PROJECT NAME</span><h2>{fieldValue(profile.name) || "Unnamed project"}</h2></div><span className="profile-source-indicator"><span className="status-dot" />Project Profile Ready</span></div><div className="profile-fact"><div className="profile-fact-head"><span>Problem</span><SourcePill source={profile.problem.source} /></div><p>{fieldValue(profile.problem) || <em className="unknown-inline">Not established yet</em>}</p></div><div className="profile-fact"><div className="profile-fact-head"><span>Project description</span><SourcePill source={profile.solution.source} /></div><p>{fieldValue(profile.solution) || <em className="unknown-inline">Not established yet</em>}</p></div><div className="profile-columns"><ProfileList label="TARGET USERS" field={profile.targetUsers} /><ProfileList label="CORE FEATURES" field={profile.coreFeatures} /><ProfileList label="TECHNOLOGIES" field={profile.technologies} /></div></div><aside className="profile-unknowns"><div className="unknown-stamp"><CircleHelp size={15} /> DETAILS TO ADD</div><p>Some details are still missing.</p>{profile.unknowns.length ? <ul>{profile.unknowns.map((item, index) => <li key={index}>{item}</li>)}</ul> : <span className="unknown-inline">No unresolved profile fields were returned.</span>}</aside></div></section>
    <details className="profile-extension"><summary className="profile-extension-summary"><span>More project details</span><ChevronDown size={18} /></summary><div className="profile-extension-heading">Each detail keeps its source label.</div><div className="profile-extension-grid"><ProfileList label="PLANNED FEATURES" field={profile.plannedFeatures} /><ProfileList label="ARCHITECTURE" field={profile.architecture} /><ProfileList label="POTENTIAL DIFFERENTIATORS" field={profile.differentiators} /><ProfileList label="CONSTRAINTS" field={profile.constraints} /></div></details>
    <div className="profile-edit-row"><span>You can edit details we inferred.</span><button className="profile-edit-toggle" onClick={openProfileEditor}><span>Edit project details</span><ArrowRight size={14} /></button></div>
    {editingProfile && <div className="profile-editor" id="profile-editor"><div className="profile-editor-heading"><div><span>EDIT PROJECT PROFILE</span><h3>Update your project details.</h3></div><button className="profile-edit-cancel" onClick={() => setEditingProfile(false)}><X size={14} />Close</button></div><div className="profile-editor-grid"><DetailField id="edit-project-name" label="PROJECT NAME" value={profileDraft.projectName} placeholder="Optional" onChange={value => updateProfileDraft("projectName", value)} /><DetailField id="edit-target-users" label="TARGET USERS" value={profileDraft.targetUsers} placeholder="If known" onChange={value => updateProfileDraft("targetUsers", value)} /><label className="profile-editor-area" htmlFor="edit-problem"><span className="field-label">PROBLEM</span><textarea id="edit-problem" className="detail-textarea" rows={3} value={profileDraft.problemStatement || ""} onChange={event => updateProfileDraft("problemStatement", event.target.value)} /></label><label className="profile-editor-area" htmlFor="edit-solution"><span className="field-label">PROPOSED SOLUTION</span><textarea id="edit-solution" className="detail-textarea" rows={3} value={profileDraft.projectDescription || ""} onChange={event => updateProfileDraft("projectDescription", event.target.value)} /></label><label className="profile-editor-area" htmlFor="edit-core-features"><span className="field-label">CORE FEATURES</span><textarea id="edit-core-features" className="detail-textarea" rows={2} value={profileDraft.existingFeatures || ""} onChange={event => updateProfileDraft("existingFeatures", event.target.value)} /></label><label className="profile-editor-area" htmlFor="edit-planned-features"><span className="field-label">PLANNED FEATURES</span><textarea id="edit-planned-features" className="detail-textarea" rows={2} value={profileDraft.plannedFeatures || ""} onChange={event => updateProfileDraft("plannedFeatures", event.target.value)} /></label><DetailField id="edit-technologies" label="TECHNOLOGIES" value={profileDraft.technologies} placeholder="If known" onChange={value => updateProfileDraft("technologies", value)} /><DetailField id="edit-architecture" label="ARCHITECTURE" value={profileDraft.architecture} placeholder="If known" onChange={value => updateProfileDraft("architecture", value)} /><label className="profile-editor-area" htmlFor="edit-constraints"><span className="field-label">CONSTRAINTS</span><textarea id="edit-constraints" className="detail-textarea" rows={2} value={profileDraft.constraints || ""} onChange={event => updateProfileDraft("constraints", event.target.value)} /></label><label className="profile-editor-area" htmlFor="edit-differentiators"><span className="field-label">DESIRED DIFFERENTIATORS</span><textarea id="edit-differentiators" className="detail-textarea" rows={2} value={profileDraft.desiredImprovements || ""} onChange={event => updateProfileDraft("desiredImprovements", event.target.value)} /></label></div><div className="profile-editor-footer"><span>Only changed fields are re-sent as user-provided; untouched observations keep their source.</span><button className="profile-edit-submit" onClick={() => onReanalyze(changedProfile())}><RotateCcw size={14} />Save and run again</button></div></div>}

    <section className="dossier-section comparison-section" id="comparables"><div className="section-heading"><div><div className="section-kicker"><span>02</span> SIMILAR PROJECTS / {report.candidates.length} FOUND</div><h2>Similar projects, in one place.</h2></div><p className="section-side-note">These are the closest matches found. Similarity is a useful signal, not a quality score.</p></div>
      {report.candidates.length ? <div className="candidate-list">{report.candidates.map((candidate, index) => <CandidateCard candidate={candidate} index={index} key={candidate.id} />)}</div> : <div className="empty-evidence"><div className="empty-evidence-icon"><Search size={21} /></div><div className="empty-evidence-copy"><strong>No comparable projects came back in this run.</strong><p>That is a search limitation, not proof that none exist. Refine the problem details or rerun the same search.</p>{report.submittedRepository && <a className="repository-evidence-link repository-evidence-link-wide" href={report.submittedRepository.url} target="_blank" rel="noreferrer"><Github size={14} />Open submitted repository · {report.submittedRepository.evidenceCount} evidence items inspected<ArrowUpRight size={13} /></a>}<div className="empty-state-actions"><button type="button" className="empty-state-button empty-state-primary" onClick={() => focusProfileField("edit-problem")}><ArrowRight size={15} />Refine this brief</button><button type="button" className="empty-state-button empty-state-secondary" onClick={onRetry}><RotateCcw size={15} />Search again</button></div></div></div>}
      {report.candidates.length > 0 && <ComparisonRadar metrics={radarMetrics} candidateCount={candidateColumns.length} />}
    </section>

    <section className="dossier-section overlap-section" id="feature-overlap"><div className="section-heading"><div><div className="section-kicker"><span>03</span> FEATURE COMPARISON</div><h2>Shared features, at a glance</h2></div><p className="section-side-note">Text matches in project notes and search results—not proof a feature works. Empty means we did not find evidence.</p></div>
      {candidateColumns.length && featureRows.length ? <div className="matrix-wrap"><table className="feature-matrix"><thead><tr><th>Capability / feature</th><th className="user-column">YOUR PROJECT</th>{candidateColumns.map(candidate => <th key={candidate.id}>{candidate.name.split("/").pop()}</th>)}</tr></thead><tbody>{featureRows.map(({ feature, source }, rowIndex) => { const origin = source === "USER-PROVIDED" ? "Proposed by user" : source === "REPOSITORY-OBSERVED" ? "Observed in repo" : "AI inference"; return <tr key={`${feature}-${rowIndex}`}><th>{feature}<SourcePill source={source} /></th><td className="user-column"><span className={`matrix-status ${source === "USER-PROVIDED" ? "matrix-proposed" : "matrix-unknown"}`}>{origin}</span></td>{candidateColumns.map(candidate => { const exact = candidate.sharedFeatures.some(item => item.toLowerCase() === feature.toLowerCase()); const partial = !exact && candidate.sharedFeatures.some(item => item.toLowerCase().includes(feature.toLowerCase()) || feature.toLowerCase().includes(item.toLowerCase())); return <td key={candidate.id}>{exact ? <span className="matrix-status matrix-found"><Check size={12} />Evidence found</span> : partial ? <span className="matrix-status matrix-partial"><CircleHelp size={12} />Partial evidence</span> : <span className="matrix-status matrix-unknown">Not established</span>}</td>; })}</tr>; })}</tbody></table></div> : <div className="matrix-empty"><span className="matrix-empty-mark"><Sparkles size={19} /></span><div className="matrix-empty-content"><p>{report.submittedRepository?.features.length ? "We found these feature signals in the submitted repository. They are observed evidence, not proof that every capability works end to end." : "Feature overlap needs both your project feature list and comparable evidence. Add a few planned or existing features to sharpen the matrix."}</p>{report.submittedRepository?.features.length ? <><TagList items={report.submittedRepository.features} /><a className="repository-evidence-link" href={report.submittedRepository.url} target="_blank" rel="noreferrer"><Github size={14} />Review submitted repository<ArrowUpRight size={13} /></a></> : null}<div className="matrix-empty-actions"><button type="button" className="matrix-empty-action" onClick={() => focusProfileField("edit-core-features")}><Plus size={15} />Add project features</button><button type="button" className="matrix-empty-action matrix-empty-retry" onClick={onRetry}><RotateCcw size={14} />Search again</button></div></div></div>}
      {overlap.length > 0 && <div className="overlap-bars"><div className="overlap-chart-label">HEURISTIC SIMILARITY / COMPARISON SIGNAL</div>{overlap.map((item, index) => <div className="overlap-bar-row" key={`${item.name}-${index}`}><span>{item.name}</span><div className="bar-track">{typeof item.score === "number" && <span style={{ width: `${Math.max(0, Math.min(100, item.score))}%` }} />}</div><span className="bar-score">{item.score === null ? "Not assessed" : `${item.score}%`}</span><small>{countLabel(item.features, "shared signal")}</small></div>)}</div>}
    </section>

    <section className="dossier-section opportunities-section" id="opportunities"><div className="section-heading"><div><div className="section-kicker"><span>04</span> IDEAS TO TRY / 3 DIRECTIONS</div><h2>Ways to make your idea stand out</h2></div><p className="section-side-note">Sorted by fit, user value, and effort. These are ideas to test, not guarantees.</p></div><div className="opportunity-grid">{report.opportunities.map((opportunity, index) => <OpportunityCard key={opportunity.id} opportunity={opportunity} number={index + 1} selected={selectedPath === opportunity.id} onClick={() => onSelectPath(opportunity.id)} />)}</div>
      {selectedProposal && selectedPath && <div className="proposal-panel"><div className="proposal-header"><div><div className="section-kicker"><span>05</span> INNOVATION FORK / SELECTED DIRECTION</div><h3>{selectedProposal.concept}</h3></div><button className="close-proposal" aria-label="Close proposal" onClick={() => onSelectPath("")}><X size={16} /></button></div><p className="proposal-intro">A first-pass project proposal grounded in the selected direction and the profile you gave us.</p><div className="proposal-grid"><ProposalField label="PROBLEM" value={selectedProposal.problem} /><ProposalField label="TARGET USERS" value={selectedProposal.users} /><div className="proposal-field"><span>CORE FEATURES</span><ul>{selectedProposal.features.map((feature: string, index: number) => <li key={index}>{feature}</li>)}</ul></div><ProposalField label="DIFFERENTIATING FEATURE" value={selectedProposal.differentiator} /><ProposalField label="IMPLEMENTATION OUTLINE" value={selectedProposal.approach} /><ProposalField label="ESTIMATED COMPLEXITY" value={selectedProposal.complexity} /><ProposalField label="VALIDATION PLAN" value={selectedProposal.validation} /></div></div>}
    </section>

    <details className="dossier-section limitations-section" id="limitations"><summary className="limitations-summary"><span>What this analysis can and cannot tell you</span><ChevronDown size={18} /></summary><div className="limits-card"><div className="limits-icon"><BookOpen size={17} /></div><div><p>Search is a starting point, not an exhaustive survey. A repository README can describe a capability without proving it works end to end. Search snippets may not reflect current product behavior. Treat the ideas above as experiments, and follow linked sources before making a product or technical decision.</p><div className="limits-links">{citations.slice(0, 4).map((item, index) => <a href={item.url} target="_blank" rel="noreferrer" key={`${item.url}-${index}`}>{item.label}<ExternalLink size={11} /></a>)}</div></div></div></details>
    <footer className="results-footer"><span>BEYOND · SOURCES GUIDE DECISIONS</span><button onClick={onNew}><Plus size={14} />Start a new brief</button></footer>
  </section>;
}

function ComparisonRadar({ metrics, candidateCount }: { metrics: { key: string; label: string; value: number | null }[]; candidateCount: number }) {
  if (metrics.length !== 4 || metrics.some(metric => metric.value === null)) {
    return <div className="dimension-radar-empty">Dimension radar withheld: this shortlist does not have support for all four comparison dimensions.</div>;
  }
  const values = metrics as Array<{ key: string; label: string; value: number }>;
  const center = 110;
  const radius = 62;
  const point = (index: number, scale: number) => {
    const angle = (Math.PI * 2 * index) / values.length - Math.PI / 2;
    return { x: center + Math.cos(angle) * radius * scale, y: center + Math.sin(angle) * radius * scale };
  };
  const polygon = (scale: number) => values.map((_, index) => { const p = point(index, scale); return `${p.x},${p.y}`; }).join(" ");
  const scorePolygon = values.map((metric, index) => { const p = point(index, metric.value / 100); return `${p.x},${p.y}`; }).join(" ");
  return <div className="dimension-radar-panel">
    <div className="dimension-radar-copy"><span className="overlap-chart-label">COMPARISON PROFILE / HEURISTIC DIMENSIONS</span><p>Mean scores across the {candidateCount} returned comparables shown above. These are interpretive signals, not measures of quality or novelty.</p><div className="dimension-radar-values">{values.map(metric => <div key={metric.key}><span>{metric.label}</span><strong>{metric.value}%</strong></div>)}</div></div>
    <svg className="dimension-radar" viewBox="0 0 220 220" role="img" aria-label={`Average heuristic similarity dimensions across ${candidateCount} comparable projects`}>
      {[0.25, 0.5, 0.75, 1].map(scale => <polygon key={scale} points={polygon(scale)} className="radar-gridline" />)}
      {values.map((metric, index) => { const end = point(index, 1); const label = point(index, 1.28); return <g key={metric.key}><line x1={center} y1={center} x2={end.x} y2={end.y} className="radar-spoke" /><text x={label.x} y={label.y} className="radar-axis-label">{metric.label}</text></g>; })}
      <polygon points={scorePolygon} className="radar-score-area" />
      {values.map((metric, index) => { const p = point(index, metric.value / 100); return <circle key={metric.key} cx={p.x} cy={p.y} r="3" className="radar-score-point"><title>{metric.label}: {metric.value}% mean heuristic signal</title></circle>; })}
    </svg>
  </div>;
}

function ProfilePreviewCard({ profile }: { profile: ProjectProfile }) {
  return <aside className="progress-profile-preview" aria-live="polite">
    <div className="progress-profile-preview-head"><div><span>PROFILE / BUILT BEFORE SEARCH</span><strong>{fieldValue(profile.name) || "Working title not established"}</strong></div><SourcePill source={profile.name.source} /></div>
    <div className="progress-profile-facts">
      <div><span>PROBLEM</span><p>{fieldValue(profile.problem) || "Not established yet"}</p><SourcePill source={profile.problem.source} /></div>
      <div><span>PROPOSED SOLUTION</span><p>{fieldValue(profile.solution) || "Not established yet"}</p><SourcePill source={profile.solution.source} /></div>
      <div><span>TARGET USERS</span><p>{fieldValue(profile.targetUsers) || "Not established yet"}</p><SourcePill source={profile.targetUsers.source} /></div>
    </div>
    <div className="progress-profile-unknowns"><strong>DETAILS TO ADD</strong><span>{profile.unknowns.length ? profile.unknowns.slice(0, 4).join(" · ") : "No unresolved fields were returned."}</span></div>
  </aside>;
}

function ProfileList({ label, field }: { label: string; field: Sourced<string[]> | Sourced<string> }) {
  const items = Array.isArray(field.value) ? field.value : field.value ? [field.value] : [];
  return <div className="profile-list"><div className="profile-fact-head"><span>{label}</span><SourcePill source={field.source} /></div><TagList items={items} muted={!items.length} /></div>;
}

function CandidateCard({ candidate, index }: { candidate: ComparableProject; index: number }) {
  const [open, setOpen] = useState(false);
  return <article className="candidate-card"><div className="candidate-index">{String(index + 1).padStart(2, "0")}</div><div className="candidate-body"><div className="candidate-top"><div className="candidate-title-wrap"><a className="candidate-name" href={candidate.url} target="_blank" rel="noreferrer">{candidate.name}<ArrowUpRight size={15} /></a><span className={`source-type source-type-${candidate.source.toLowerCase()}`}>{candidate.source === "GitHub" ? <Github size={12} /> : <Search size={12} />}{candidate.source}</span></div><div className="candidate-score"><strong>{candidate.similarity === null ? "—" : `${candidate.similarity}%`}</strong><span>Similarity signal</span></div></div><p className="candidate-description">{candidate.description}</p>{candidate.source === "GitHub" && <a className="candidate-repo-link" href={candidate.url} target="_blank" rel="noreferrer"><Github size={14} />Visit repository on GitHub<ArrowUpRight size={13} /></a>}<div className="candidate-relevance"><strong className="relevance-label">Why it may be similar</strong><span className="relevance-copy">{candidate.whyRelevant}</span></div><div className="candidate-chip-row"><div><span className="candidate-mini-label">SHARED FEATURES</span><TagList items={candidate.sharedFeatures} muted={!candidate.sharedFeatures.length} /></div>{candidate.distinctiveFeatures.length > 0 && <div><span className="candidate-mini-label">POSSIBLE DIFFERENCES</span><TagList items={candidate.distinctiveFeatures} /></div>}</div><button className="evidence-toggle" onClick={() => setOpen(!open)} aria-expanded={open}><span><FileSearch size={14} />{open ? "Hide" : "View"} sources and evidence</span><ChevronDown size={14} className={open ? "chevron-up" : ""} /></button>{open && <div className="evidence-details"><div className="evidence-details-title">SOURCES AND EVIDENCE</div>{candidate.evidence.length ? candidate.evidence.map((item, evidenceIndex) => <a className="evidence-item" href={item.url} target="_blank" rel="noreferrer" key={`${item.url}-${evidenceIndex}`}><span className="evidence-item-status">{item.status}</span><strong>{item.label}<ExternalLink size={11} /></strong><p>{item.excerpt || "No excerpt was returned by the source."}</p></a>) : <p className="unknown-inline">No direct source excerpt was returned.</p>}<div className="evidence-limitations">{candidate.limitations.map((item, limitIndex) => <p key={limitIndex}><CircleHelp size={13} />{item}</p>)}</div><div className="repo-meta">{candidate.language && <span>{candidate.language}</span>}{typeof candidate.stars === "number" && <span>{candidate.stars.toLocaleString()} stars</span>}{typeof candidate.forks === "number" && <span>{candidate.forks.toLocaleString()} forks</span>}{candidate.license && <span>License: {candidate.license}</span>}{candidate.updatedAt && <span>Updated {new Date(candidate.updatedAt).toLocaleDateString()}</span>}</div></div>}</div></article>;
}

function OpportunityCard({ opportunity, number, selected, onClick }: { opportunity: InnovationOpportunity; number: number; selected: boolean; onClick: () => void }) {
  const icons = [<Sparkles size={16} key="spark" />, <Compass size={16} key="compass" />, <Lightbulb size={16} key="bulb" />];
  const evidenceBlock = opportunity.evidence.length > 0
    ? <div className="opportunity-evidence"><span>EVIDENCE TO REVIEW</span>{opportunity.evidence.map((item, index) => <a href={item.url} target="_blank" rel="noreferrer" key={`${item.projectName}-${index}`}>{item.projectName}<ArrowUpRight size={11} /></a>)}</div>
    : <div className="opportunity-evidence opportunity-evidence-empty"><span>EVIDENCE TO REVIEW</span><p>No comparable source supported this direction; treat it as a hypothesis grounded in the project profile.</p></div>;
  return <article className={`opportunity-card ${selected ? "opportunity-selected" : ""}`}><div className="opportunity-top"><span className="opportunity-number">PATH {String(number).padStart(2, "0")}</span><span className="opportunity-kind">{opportunity.kind}</span></div><div className="opportunity-icon">{icons[number - 1] || <Sparkles size={16} />}</div><h3>{opportunity.title}</h3><p className="opportunity-proposal">{opportunity.proposal}</p><div className="opportunity-reason"><span>WHY IT MATTERS</span><p>{opportunity.whyDifferent || opportunity.problem}</p></div>{evidenceBlock}<div className="opportunity-bottom"><span className={`effort effort-${opportunity.effort.toLowerCase()}`}><i />{opportunity.effort.toLowerCase() === "low" ? "Quick Win" : opportunity.effort.toLowerCase() === "medium" ? "Moderate Effort" : "Advanced"}</span><span className="opportunity-benefit">{opportunity.benefit}</span></div><div className="validation-line"><span>NEXT STEP</span><p>{opportunity.validation}</p></div>{opportunity.uncertainties.length > 0 && <details className="uncertainty-details"><summary>What’s still uncertain <ChevronDown size={13} /></summary><ul>{opportunity.uncertainties.map((item, index) => <li key={index}>{item}</li>)}</ul></details>}<button className="explore-path" onClick={onClick}>{selected ? "Selected" : "Explore this idea"}{selected ? <Check size={14} /> : <ArrowRight size={14} />}</button></article>;
}
function ProposalField({ label, value }: { label: string; value: string }) { return <div className="proposal-field"><span>{label}</span><p>{value || "Not established yet"}</p></div>; }
