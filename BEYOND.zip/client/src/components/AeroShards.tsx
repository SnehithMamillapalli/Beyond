import { useEffect, useRef } from "react";

type AeroShardsProps = {
  shardColor?: string;
  accentColor?: string;
  placement?: "full" | "band";
  material?: "glass" | "solid";
  markers?: "plus" | "none";
  count?: number;
  depthOfField?: number;
  vignette?: number;
  mouseInteraction?: boolean;
  pulseOnClick?: boolean;
  holdToGather?: boolean;
};

type Shard = {
  x: number;
  y: number;
  size: number;
  depth: number;
  angle: number;
  spin: number;
  phase: number;
  vertices: number;
  accent: boolean;
};

type PointerState = { x: number; y: number; active: boolean; down: boolean };
type Pulse = { x: number; y: number; startedAt: number };

type RGB = readonly [number, number, number];

function rgbFromHex(color: string): RGB {
  const value = color.replace("#", "").trim();
  const expanded = value.length === 3 ? value.split("").map((part) => part + part).join("") : value;
  const number = Number.parseInt(expanded.slice(0, 6), 16);
  if (!Number.isFinite(number)) return [137, 167, 121];
  return [(number >> 16) & 255, (number >> 8) & 255, number & 255];
}

function rgba([red, green, blue]: RGB, alpha: number) {
  return `rgba(${red}, ${green}, ${blue}, ${Math.max(0, Math.min(1, alpha))})`;
}

function makeShards(width: number, height: number, count: number): Shard[] {
  return Array.from({ length: count }, () => {
    const x = Math.random();
    const depth = Math.random();
    const ribbon = Math.random() < 0.78;
    const center = 0.5 + 0.17 * Math.sin(x * Math.PI * 2 - 0.55);
    const spread = 0.025 + depth * 0.16;
    const y = ribbon ? center + (Math.random() - 0.5) * spread : Math.random();
    return {
      x,
      y: Math.max(-0.08, Math.min(1.08, y)),
      size: (2.5 + Math.random() * 14) * (0.38 + depth * 1.15),
      depth,
      angle: Math.random() * Math.PI * 2,
      spin: (Math.random() - 0.5) * 1.3,
      phase: Math.random() * Math.PI * 2,
      vertices: 3 + Math.floor(Math.random() * 3),
      accent: Math.random() < 0.16,
    };
  });
}

export default function AeroShards({
  shardColor = "#89A779",
  accentColor = "#D2E66F",
  placement = "full",
  material = "glass",
  markers = "plus",
  count = 1300,
  depthOfField = 0.75,
  vignette = 0.3,
  mouseInteraction = true,
  pulseOnClick = true,
  holdToGather = true,
}: AeroShardsProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d", { alpha: false });
    if (!canvas || !context) return;

    const shardRGB = rgbFromHex(shardColor);
    const accentRGB = rgbFromHex(accentColor);
    const safeCount = Math.max(100, Math.min(2000, count));
    const safeDof = Math.max(0, Math.min(1, depthOfField));
    const safeVignette = Math.max(0, Math.min(1, vignette));
    const pointer: PointerState = { x: 0, y: 0, active: false, down: false };
    let pulse: Pulse | null = null;
    let width = 1;
    let height = 1;
    let dpr = 1;
    let shards: Shard[] = [];
    let raf = 0;
		let lastFrame = 0;
		let animationUntil = performance.now() + 1400;
		let reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		let pageHidden = document.hidden;
		let hazeGradient: CanvasGradient | null = null;
		let ribbonGradient: CanvasGradient | null = null;
		let edgeGradient: CanvasGradient | null = null;

    const resize = () => {
      width = Math.max(1, window.innerWidth);
      height = Math.max(1, window.innerHeight);
			dpr = Math.min(window.devicePixelRatio || 1, 1.15);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
			context.setTransform(dpr, 0, 0, dpr, 0, 0);
			shards = makeShards(width, height, safeCount);
			hazeGradient = context.createRadialGradient(width * 0.52, height * 0.48, 0, width * 0.52, height * 0.48, Math.max(width, height) * 0.82);
			hazeGradient.addColorStop(0, rgba(accentRGB, 0.075));
			hazeGradient.addColorStop(0.58, rgba(shardRGB, 0.045));
			hazeGradient.addColorStop(1, "rgba(16, 42, 36, 0)");
			ribbonGradient = context.createLinearGradient(0, height * 0.4, width, height * 0.62);
			ribbonGradient.addColorStop(0, rgba(shardRGB, 0));
			ribbonGradient.addColorStop(0.32, rgba(shardRGB, 0.42));
			ribbonGradient.addColorStop(0.58, rgba(accentRGB, 0.3));
			ribbonGradient.addColorStop(0.82, rgba(shardRGB, 0.36));
			ribbonGradient.addColorStop(1, rgba(shardRGB, 0));
			edgeGradient = context.createRadialGradient(width * 0.5, height * 0.48, Math.min(width, height) * 0.2, width * 0.5, height * 0.48, Math.max(width, height) * 0.78);
			edgeGradient.addColorStop(0, "rgba(3, 15, 11, 0)");
			edgeGradient.addColorStop(1, rgba([4, 17, 13], safeVignette * 0.48));
			render(performance.now());
    };

    const render = (now: number) => {
      context.save();
      context.setTransform(dpr, 0, 0, dpr, 0, 0);
      context.globalCompositeOperation = "source-over";
      context.filter = "none";
		context.fillStyle = "#edf0e7";
      context.fillRect(0, 0, width, height);

		context.fillStyle = hazeGradient || "rgba(237, 240, 231, 0)";
		context.fillRect(0, 0, width, height);

		const drawRibbon = () => {
        context.beginPath();
        context.moveTo(-width * 0.08, height * 0.42);
        context.bezierCurveTo(width * 0.23, height * 0.28, width * 0.31, height * 0.7, width * 0.54, height * 0.55);
        context.bezierCurveTo(width * 0.74, height * 0.4, width * 0.83, height * 0.76, width * 1.08, height * 0.53);
        context.stroke();
      };
      context.save();
      context.globalAlpha = 0.27;
		context.strokeStyle = ribbonGradient || "transparent";
		context.lineWidth = Math.max(18, height * 0.075);
		drawRibbon();
      context.restore();
      context.save();
      context.globalAlpha = 0.23;
		context.strokeStyle = ribbonGradient || "transparent";
      context.lineWidth = Math.max(1.2, height * 0.002);
      context.setLineDash([2, 8]);
      drawRibbon();
      context.setLineDash([]);
      context.restore();

      const time = now * 0.001;
      const pointerRadius = Math.min(width, height) * 0.22;
      const pulseAge = pulse ? (now - pulse.startedAt) / 1150 : 2;
      const pulseRadius = pulseAge * Math.max(width, height) * 0.56;

      for (let index = 0; index < shards.length; index += 1) {
        const shard = shards[index];
        let x = shard.x * width + Math.sin(time * 0.42 + shard.phase) * shard.size * 0.22;
        let y = shard.y * height + Math.cos(time * 0.36 + shard.phase) * shard.size * 0.18;

        if (mouseInteraction && pointer.active) {
          const dx = x - pointer.x;
          const dy = y - pointer.y;
          const distance = Math.max(1, Math.hypot(dx, dy));
          const influence = Math.max(0, 1 - distance / pointerRadius);
          if (influence > 0) {
            if (holdToGather && pointer.down) {
              const gather = influence * (0.22 + shard.depth * 0.18);
              x += (pointer.x + Math.cos(shard.phase) * shard.size * 1.8 - x) * gather;
              y += (pointer.y + Math.sin(shard.phase) * shard.size * 1.8 - y) * gather;
            } else {
              const repel = influence * (7 + shard.depth * 18);
              x += (dx / distance) * repel;
              y += (dy / distance) * repel;
            }
          }
        }

        if (pulse && pulseAge >= 0 && pulseAge <= 1) {
          const dx = x - pulse.x;
          const dy = y - pulse.y;
          const distance = Math.max(1, Math.hypot(dx, dy));
          const ring = Math.exp(-Math.pow((distance - pulseRadius) / 24, 2)) * (1 - pulseAge);
          x += (dx / distance) * ring * 34;
          y += (dy / distance) * ring * 34;
        }

        const rotation = shard.angle + time * 0.08 * shard.spin;
        const size = shard.size * (0.82 + shard.depth * 0.24);
        const color = shard.accent ? accentRGB : shardRGB;
			const opacity = (material === "glass" ? 0.2 : 0.24) + shard.depth * (material === "glass" ? 0.3 : 0.34);
			context.save();
			context.translate(x, y);
			context.rotate(rotation);
			context.beginPath();
        for (let vertex = 0; vertex < shard.vertices; vertex += 1) {
          const angle = (vertex / shard.vertices) * Math.PI * 2;
          const length = size * (vertex % 2 === 0 ? 1 : 0.48 + ((shard.phase * 10) % 0.28));
          const px = Math.cos(angle) * length;
          const py = Math.sin(angle) * length * (0.58 + shard.depth * 0.18);
          if (vertex === 0) context.moveTo(px, py);
          else context.lineTo(px, py);
        }
        context.closePath();
			context.fillStyle = rgba(color, opacity * 0.3);
        context.strokeStyle = rgba(color, opacity * 0.95);
        context.lineWidth = 0.45 + shard.depth * 0.5;
        context.fill();
        context.stroke();
        if (material === "glass" && shard.depth > 0.62) {
          context.beginPath();
          context.moveTo(-size * 0.42, -size * 0.18);
          context.lineTo(size * 0.28, -size * 0.1);
          context.strokeStyle = rgba(accentRGB, opacity * 0.68);
          context.lineWidth = 0.55;
          context.stroke();
        }
        context.restore();

        if (markers === "plus" && index % 47 === 0) {
          const markerSize = 2 + shard.depth * 1.7;
          context.save();
          context.strokeStyle = rgba(accentRGB, 0.18 + shard.depth * 0.25);
          context.lineWidth = 0.7;
          context.beginPath();
          context.moveTo(x - markerSize, y);
          context.lineTo(x + markerSize, y);
          context.moveTo(x, y - markerSize);
          context.lineTo(x, y + markerSize);
          context.stroke();
          context.restore();
        }
      }

      if (pulse && pulseAge >= 0 && pulseAge <= 1 && pulseOnClick) {
        context.beginPath();
        context.arc(pulse.x, pulse.y, pulseRadius, 0, Math.PI * 2);
        context.strokeStyle = rgba(accentRGB, (1 - pulseAge) * 0.34);
        context.lineWidth = 1.2;
        context.setLineDash([3, 7]);
        context.stroke();
        context.setLineDash([]);
      } else if (pulseAge > 1) {
        pulse = null;
      }

      if (safeVignette > 0) {
			context.fillStyle = edgeGradient || "transparent";
			context.fillRect(0, 0, width, height);
      }

      context.restore();
    };

    const animate = (now: number) => {
		if (reducedMotion || pageHidden) {
			raf = 0;
			if (!pageHidden) render(now);
			return;
		}
		if (now - lastFrame >= 1000 / 24) {
        render(now);
        lastFrame = now;
      }
      if (pointer.down || now < animationUntil || (pulse && now - pulse.startedAt <= 1150)) {
        raf = window.requestAnimationFrame(animate);
      } else {
        raf = 0;
        render(now);
      }
    };

    const start = (duration = 0) => {
      animationUntil = Math.max(animationUntil, performance.now() + duration);
      if (reducedMotion) render(performance.now());
      else if (!raf) raf = window.requestAnimationFrame(animate);
    };

    const updatePointer = (event: PointerEvent) => {
      pointer.x = event.clientX;
      pointer.y = event.clientY;
      pointer.active = true;
      if (reducedMotion) render(performance.now());
      else start(280);
    };
    const onPointerDown = (event: PointerEvent) => {
      pointer.down = true;
      updatePointer(event);
      start(1150);
    };
    const onPointerUp = () => {
      pointer.down = false;
      if (reducedMotion) render(performance.now());
      else start(280);
    };
    const onClick = (event: MouseEvent) => {
      if (!pulseOnClick || event.detail === 0) return;
      pulse = { x: event.clientX, y: event.clientY, startedAt: performance.now() };
      if (reducedMotion) render(performance.now());
      else start(1150);
    };
    const onMotionPreference = (event: MediaQueryListEvent) => {
      reducedMotion = event.matches;
      if (reducedMotion && raf) {
        window.cancelAnimationFrame(raf);
        raf = 0;
        render(performance.now());
      } else start();
    };
		const onBlur = () => {
			pointer.down = false;
			pointer.active = false;
		};
		const onVisibilityChange = () => {
			pageHidden = document.hidden;
			if (pageHidden && raf) {
				window.cancelAnimationFrame(raf);
				raf = 0;
			} else if (!pageHidden) {
				start(280);
			}
		};

    const motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    motionQuery.addEventListener("change", onMotionPreference);
    window.addEventListener("resize", resize, { passive: true });
    window.addEventListener("pointermove", updatePointer, { passive: true });
    window.addEventListener("pointerdown", onPointerDown, { passive: true });
    window.addEventListener("pointerup", onPointerUp, { passive: true });
    window.addEventListener("pointercancel", onPointerUp, { passive: true });
		window.addEventListener("click", onClick);
		window.addEventListener("blur", onBlur);
		document.addEventListener("visibilitychange", onVisibilityChange);
    resize();
    start();

    return () => {
      if (raf) window.cancelAnimationFrame(raf);
      motionQuery.removeEventListener("change", onMotionPreference);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", updatePointer);
      window.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
		window.removeEventListener("click", onClick);
		window.removeEventListener("blur", onBlur);
		document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [accentColor, count, depthOfField, holdToGather, markers, material, mouseInteraction, placement, pulseOnClick, shardColor, vignette]);

  return <canvas ref={canvasRef} className="aero-shards" aria-hidden="true" />;
}
